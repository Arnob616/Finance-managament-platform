'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  PlusCircle, 
  Calendar,
  Target,
  CreditCard,
  Wallet
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface Budget {
  id: string;
  name: string;
  amount: number;
  spent: number;
  period: string;
  category: string;
  notes?: string;
}

interface Transaction {
  id: string;
  amount: number;
  description: string;
  category: string;
  type: 'INCOME' | 'EXPENSE';
  date: string;
}

export default function Dashboard() {
  const { data: session } = useSession();
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  // Mock data for demonstration
  const mockBudgets: Budget[] = [
    { id: '1', name: 'Monthly Groceries', amount: 500, spent: 320, period: 'MONTHLY', category: 'Food', notes: 'Family groceries' },
    { id: '2', name: 'Weekly Entertainment', amount: 100, spent: 75, period: 'WEEKLY', category: 'Entertainment', notes: 'Movies and dining' },
    { id: '3', name: 'Daily Coffee', amount: 15, spent: 8, period: 'DAILY', category: 'Food', notes: 'Morning coffee' },
  ];

  const mockTransactions: Transaction[] = [
    { id: '1', amount: 45.50, description: 'Grocery Store', category: 'Food', type: 'EXPENSE', date: '2025-01-15' },
    { id: '2', amount: 2500.00, description: 'Salary', category: 'Income', type: 'INCOME', date: '2025-01-15' },
    { id: '3', amount: 25.00, description: 'Gas Station', category: 'Transportation', type: 'EXPENSE', date: '2025-01-14' },
    { id: '4', amount: 120.00, description: 'Electricity Bill', category: 'Utilities', type: 'EXPENSE', date: '2025-01-14' },
  ];

  const chartData = [
    { name: 'Jan', income: 2500, expenses: 1800 },
    { name: 'Feb', income: 2500, expenses: 1900 },
    { name: 'Mar', income: 2600, expenses: 1750 },
    { name: 'Apr', income: 2400, expenses: 1850 },
    { name: 'May', income: 2700, expenses: 1950 },
    { name: 'Jun', income: 2500, expenses: 1800 },
  ];

  const pieData = [
    { name: 'Food', value: 400, color: '#3B82F6' },
    { name: 'Transportation', value: 300, color: '#10B981' },
    { name: 'Entertainment', value: 200, color: '#F59E0B' },
    { name: 'Utilities', value: 250, color: '#EF4444' },
    { name: 'Shopping', value: 150, color: '#8B5CF6' },
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setBudgets(mockBudgets);
      setTransactions(mockTransactions);
      setLoading(false);
    }, 1000);
  }, []);

  const totalIncome = transactions.filter(t => t.type === 'INCOME').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'EXPENSE').reduce((sum, t) => sum + t.amount, 0);
  const totalBudget = budgets.reduce((sum, b) => sum + b.amount, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);

  const getBudgetProgress = (budget: Budget) => {
    return (budget.spent / budget.amount) * 100;
  };

  const getBudgetStatus = (budget: Budget) => {
    const progress = getBudgetProgress(budget);
    if (progress > 100) return 'exceeded';
    if (progress > 80) return 'warning';
    return 'on-track';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
            <DollarSign className="w-8 h-8 text-white animate-pulse" />
          </div>
          <p className="text-gray-600">Loading your financial dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">FinanceFlow</h1>
                <p className="text-sm text-gray-600">Welcome back, {session?.user?.name || 'User'}!</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <PlusCircle className="w-4 h-4 mr-2" />
                Add Transaction
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Income</CardTitle>
              <TrendingUp className="w-4 h-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">${totalIncome.toFixed(2)}</div>
              <p className="text-xs text-gray-500">+12% from last month</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Expenses</CardTitle>
              <TrendingDown className="w-4 h-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</div>
              <p className="text-xs text-gray-500">-3% from last month</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Budget Used</CardTitle>
              <Target className="w-4 h-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                ${totalSpent.toFixed(2)} / ${totalBudget.toFixed(2)}
              </div>
              <p className="text-xs text-gray-500">{((totalSpent / totalBudget) * 100).toFixed(1)}% of budget</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Net Worth</CardTitle>
              <Wallet className="w-4 h-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                ${(totalIncome - totalExpenses).toFixed(2)}
              </div>
              <p className="text-xs text-gray-500">This month</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-gray-800">Income vs Expenses</CardTitle>
              <CardDescription>Monthly comparison over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="income" stroke="#10B981" strokeWidth={2} />
                  <Line type="monotone" dataKey="expenses" stroke="#EF4444" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-gray-800">Spending by Category</CardTitle>
              <CardDescription>This month's expense breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Budget Tracking */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-gray-800">Active Budgets</CardTitle>
              <CardDescription>Track your budget progress</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {budgets.map((budget) => (
                <div key={budget.id} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-gray-800">{budget.name}</span>
                      <Badge variant={getBudgetStatus(budget) === 'exceeded' ? 'destructive' : 
                                   getBudgetStatus(budget) === 'warning' ? 'secondary' : 'default'}>
                        {budget.period}
                      </Badge>
                    </div>
                    <span className="text-sm text-gray-600">
                      ${budget.spent.toFixed(2)} / ${budget.amount.toFixed(2)}
                    </span>
                  </div>
                  <Progress 
                    value={getBudgetProgress(budget)} 
                    className="h-2"
                  />
                  {budget.notes && (
                    <p className="text-xs text-gray-500">{budget.notes}</p>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-gray-800">Recent Transactions</CardTitle>
              <CardDescription>Your latest financial activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.slice(0, 5).map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        transaction.type === 'INCOME' ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {transaction.type === 'INCOME' ? 
                          <TrendingUp className="w-4 h-4 text-green-600" /> : 
                          <CreditCard className="w-4 h-4 text-red-600" />
                        }
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{transaction.description}</p>
                        <p className="text-sm text-gray-500">{transaction.category}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-medium ${
                        transaction.type === 'INCOME' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.type === 'INCOME' ? '+' : '-'}${transaction.amount.toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-500">{transaction.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}